/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scrabble;

import java.time.ZoneId;
import java.util.Locale;

import java.time.Instant;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.time.format.DateTimeFormatter;


/**
 *
 * @authors Sebastià Ballester & Xavier Carbonell
 */
public class FitxerParaulesSortida {
    
    /*
    * Atributs de la classe
    */
    private static final char SEPARADOR = '\n';
    private FileWriter fw;
    private BufferedWriter bw;


DateTimeFormatter dateFormatter = DateTimeFormatter
            .ofPattern("EEEE dd MMMM 'de' yyyy 'a les' HH:mm:ss") // com volem que ho mostri
            .withLocale(Locale.forLanguageTag("es-ES")) // amb quina llengua
            .withZone(ZoneId.systemDefault()); // amb quina zona horària (la del sistema)   


DateTimeFormatter dateFormatter2 = DateTimeFormatter
            .ofPattern("EEEE dd MMMM 'de' yyyy 'a les' HH:mm:ss") // com volem que ho mostri
            .withLocale(Locale.forLanguageTag("ca-ES")) // amb quina llengua
            .withZone(ZoneId.systemDefault()); // amb quina zona horària (la del sistema)  

    
    /*
    * Constructor
    */
    
    public FitxerParaulesSortida(String nomFitxer, boolean append) throws Exception {
        
        fw = new FileWriter(nomFitxer, append);
        bw = new BufferedWriter(fw);
     


    }
    
    /*
    * Mètodes no statics
    */
    
    // Mètode que escriu una paraula pasada per paràmetre
    public void escriuParaula(Paraula p ) throws Exception {
        
        for (int i = 0; i < p.longitud(); i++) {
            
            bw.write(p.lletraA(i));
            
        }
        
    }
    
    //Métode per escriure l'historial al final de cada joc
    public void escriuHistorialSolitari(Paraula nom, int punts, boolean idiomaEspañol)throws Exception{
    Instant ara = Instant.now();
    long timestampAra = ara.getEpochSecond();
    ara = Instant.ofEpochSecond(timestampAra);
    

    
        if (idiomaEspañol) {
            
            bw.write("Partida de ");
            escriuParaula(nom);
            bw.write(" a solitario: Puntuación: " + punts + " puntos.");
            bw.write("(" + dateFormatter.format(ara) + ") ");
            
        } else {
            
            bw.write("Partida de ");
            escriuParaula(nom);
            bw.write(" a solitari: Puntuació: " + punts + " punts.");
            bw.write("(" + dateFormatter2.format(ara) + ") ");
            
        }
                   
        escriuSeparador();
        tanca();
        
    }
    
    public void escriuHistorialPVC(Paraula nom, int especificaMode,int punts, int puntsMaquina, boolean idiomaEspañol)throws Exception{

    Instant ara = Instant.now();
    long timestampAra = ara.getEpochSecond();
    ara = Instant.ofEpochSecond(timestampAra);
    

        
        bw.write("Partida de ");
        escriuParaula(nom);
        
        if (idiomaEspañol) {
            
            if(especificaMode == 1){
                
            
                bw.write(" de PVC (Cerebro Superior): Puntuación de ");
                escriuParaula(nom);
                bw.write(": " + punts + " puntos. ");

                bw.write("Puntuación de Cerebro Superior: " + puntsMaquina + " puntos.");

                if (puntsMaquina > punts) {
                    bw.write(" Gana Cerebro Superior.");
                } else if (punts > puntsMaquina) {
                    bw.write(" Gana ");
                    escriuParaula(nom);
                    bw.write(".");
                } else {
                    bw.write(" Empate.");
                }
            
            } else {

                bw.write(" de PVC (Simulador): Puntuación de ");
                escriuParaula(nom);
                bw.write(": " + punts + " puntos. ");

                bw.write("Puntuación del Simulador: " + puntsMaquina + " puntos.");

                if (puntsMaquina > punts) {
                    bw.write(" Gana Simulador.");
                } else if (punts > puntsMaquina) {
                    bw.write(" Gana ");
                    escriuParaula(nom);
                    bw.write(".");
                } else {
                    bw.write(" Empate.");
                }

            }
        
            bw.write("(" + dateFormatter.format(ara) + ") ");  
        } else {
            
            if(especificaMode == 1){

                bw.write(" a PVC (Cervell Superior): Puntuació de ");
                escriuParaula(nom);
                bw.write(": " + punts + " punts. ");

                bw.write("Puntuació de Cervell Superior: " + puntsMaquina + " punts.");

                if (puntsMaquina > punts) {
                    bw.write(" Guanya Cervell Superior.");
                } else if (punts > puntsMaquina) {
                    bw.write(" Guanya ");
                    escriuParaula(nom);
                    bw.write(".");
                } else {
                    bw.write(" Empat.");
                }

            } else {

                bw.write(" a PVC (Simulador): Puntuació de ");
                escriuParaula(nom);
                bw.write(": " + punts + " punts. ");

                bw.write("Puntuació de Simulador: " + puntsMaquina + " punts.");

                if (puntsMaquina > punts) {
                    bw.write(" Guanya Simulador.");
                } else if (punts > puntsMaquina) {
                    bw.write(" Guanya ");
                    escriuParaula(nom);
                    bw.write(".");
                } else {
                    bw.write(" Empat.");
                }

            }
            
                bw.write("(" + dateFormatter2.format(ara) + ") ");
        }
        
        escriuSeparador();
        tanca();
    }
    
    public void escriuHistorialPVP(Paraula nom1,Paraula nom2, Paraula nom3, Paraula nom4, int puntuacioGuanyador, Paraula nomGuanyador, int quantitatJugadors, boolean idiomaEspañol)throws Exception{

    Instant ara = Instant.now();
    long timestampAra = ara.getEpochSecond();
    ara = Instant.ofEpochSecond(timestampAra);
    

        
        if (idiomaEspañol) {
            
            bw.write("Partida de ");
            escriuParaula(nom1);
            bw.write(", ");
            escriuParaula(nom2);
            if (quantitatJugadors == 3 || quantitatJugadors == 4) {
              bw.write(", ");
              escriuParaula(nom3); 

            }
            if (quantitatJugadors == 4) {

                bw.write(", ");
                escriuParaula(nom4); 
            }

            bw.write(" de PVP: ");
            if (puntuacioGuanyador == -300) {
                bw.write("Empate!");
            }else{
             bw.write(" El ganador ha sido ");
            escriuParaula(nomGuanyador);
            bw.write(" con " + puntuacioGuanyador + " puntos.");               
            }

            bw.write("(" + dateFormatter.format(ara) + ") ");                
        } else {
            
            bw.write("Partida de ");
            escriuParaula(nom1);
            bw.write(", ");
            escriuParaula(nom2);
            if (quantitatJugadors == 3 || quantitatJugadors == 4) {

              escriuParaula(nom3); 

            }
            if (quantitatJugadors == 4) {

                bw.write(", ");
                escriuParaula(nom4); 
            }

            bw.write(" a PVP: ");
            if (puntuacioGuanyador == -300) {
                bw.write("Empat!");
            }else{
             bw.write(" El guanyador ha estat ");
            escriuParaula(nomGuanyador);
            bw.write(" amb " + puntuacioGuanyador + " punts.");               
            }

            bw.write("(" + dateFormatter2.format(ara) + ") ");         
        }
        
        escriuSeparador();
        tanca();
        
    }

    // Mètode que escriu un separador
    public void escriuSeparador() throws Exception {
        
        bw.write(SEPARADOR);
        
    }
    
    // Mètode que tanca el fitxer
    public void tanca() throws Exception {
        
        bw.close();
        fw.close();
        
    }
    
    
}
