/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scrabble;

/**
 *
 * @authors Sebastià Ballester & Xavier Carbonell
 */

import java.io.BufferedReader;
import java.io.FileReader;


public class FitxerTextEntrada {
    
    // Atributs
    
    private FileReader fr;
    private BufferedReader br;
    private int codi = CODI_ESPAI;
    
    // Constants
    
    private static final int CODI_FINAL = -1;
    private static final int CODI_ESPAI = (int) ' ';
    private static final int CODI_LF = (int) '\n';
    private static final int CODI_TAB = (int) '\t';
    
    //Constructor
    
    public FitxerTextEntrada(String nomFitxer) throws Exception {
        fr = new FileReader(nomFitxer);
        br = new BufferedReader(fr);
    }

    //Mètodes no statics
        
    // Mètode que bota els separadors fins arribar a una cosa diferent d'aquests.
    private void botaEspais() throws Exception {
        
        while (codi == CODI_ESPAI || codi == CODI_LF || codi == CODI_TAB) {
            codi = br.read();
        }
        
    }
        
    // Mètode que bota separadors i et diu si has arribat al final.
    public boolean quedenElements() throws Exception {
        botaEspais();
        return codi != CODI_FINAL;
        
    }
    
    // Mètode que et retorna el valor enter corresponent a un valor caràcter pasat per parametre (Exemple: I = '4', O = 4).
    private int valorDigit(char digit) throws Exception {
        
       return (int) digit - (int) '0';
    }

    // Mètode que llegeix una seqüencia de valors enters i els retorna en la seva forma original.
    public int llegeixEnter() throws Exception {
        int total = 0;
        
        while (codi >= '0' && codi <= '9') {
            
            total = total * 10;
            total = total + valorDigit((char) codi);
            
            codi = br.read();
            
        }
        
        return total;
    }
    
    // Mètode que bota separadors i llegeix un caràcter.
    public char llegeixLletra() throws Exception {
        char lletra = (char) codi;
        
        while (codi != CODI_FINAL && codi != CODI_LF && codi != CODI_ESPAI && codi != CODI_TAB) {
            codi = br.read();
        }
        
        return lletra;
    }
    
    // Mètode que tanca el fitxer.
    public void tanca() throws Exception {
        
        fr.close();
        br.close();
        
    }
    
    
}
