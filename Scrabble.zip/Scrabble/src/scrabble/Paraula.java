/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scrabble;

/**
 *
 * @authors Sebastià Ballester & Xavier Carbonell
 */
public class Paraula {
    
    /*
    * Atributs de la classe paraula
    */
    
    // Contingut de la paraula.
    private char[] lletres;
    // Longitud de la paraula.
    private int longitud;

    // Quantitat màxima de lletres.
    private final static int MAX = 20;

    
    // Final de la seqüència.
    private final static char FINAL = '.';
    // Separador entre paraules.
    private final static char SEPARADOR = ' ';
    // Lletra actual de la seqüència.
    private static char lletraTeclat = SEPARADOR;
    
    
    /*
    * Constructor de la classe paraula
    */
    
    public Paraula() {
        lletres = new char[MAX];
        longitud = 0;
    }
    
    /*
    * Mètodes statics de la classe paraula
    */
    
    // Mètode que cerca la següent paraula (bota espais i salta de línia).
    private static void cercaParaula() {
        while (lletraTeclat == SEPARADOR || lletraTeclat == '\n') {
            lletraTeclat = LT.readChar();
        }
    }
    
    // Mètode que cera paraula i et diu si queden paraules o no.
    public static boolean quedenParaules() {
        cercaParaula();
        return lletraTeclat != FINAL;
    }
    
    // Mètode que es pot usar per bota una paraula si fos necessari.
    private static void botaParaula() {
        while (lletraTeclat != SEPARADOR &&
                lletraTeclat != FINAL) {
            lletraTeclat = LT.readChar();
        }
    }
    
    // Aquest mètode crea les paraules mitjançant les lletres escrites per teclat (fica aquestes dins un array de lletres i li dona una longitud).
    public static Paraula llegeix() {
        // Cream la nova paraula.
        Paraula p = new Paraula();
        lletraTeclat = SEPARADOR;
        cercaParaula();
        // Mentre no haguem arribat al final de la paraula i hi càpiga.
        while (lletraTeclat != SEPARADOR && lletraTeclat != FINAL &&
                p.longitud < MAX && lletraTeclat != '\n') {
           
            p.lletres[p.longitud] = lletraTeclat;
            lletraTeclat = LT.readChar();
            p.longitud++;
        }
           
        return p;
    }
    
    // Mètode que durà a terme el Cervell Superior i servirà per triar la millor paraula del diccionari en funció de les fitxes donades
    public static Paraula triaMillorParaula(FitxerParaulesEntrada diccionari, Fitxa fitxa) throws Exception {
        int puntuacio = 0;
        int puntuacioSeguent;
        
        
        Paraula millorParaula = new Paraula();
        Paraula paraulaCercada = new Paraula();   
        
        Fitxa copiaInicialFitxes = new Fitxa();
        copiaInicialFitxes.agafaFitxes(fitxa);
        
        // Es farà un recorregut de totes les paraules del diccionari i es triarà aquella de major puntuació.
        while (diccionari.quedenParaules()) {

            paraulaCercada = diccionari.llegeixParaula();
            
            fitxa.agafaFitxes(copiaInicialFitxes);
            if (paraulaCercada.paraulaValida(fitxa.retornaFitxesUsuari())){
                puntuacioSeguent = fitxa.retornaPunts(paraulaCercada); 
                
                if(puntuacioSeguent > puntuacio){
                    
                    millorParaula.ompleParaula(paraulaCercada);
                
                }
                                
            }
            
        }
        
        return millorParaula;
    }
    
    //Mètode que defineix l'algorisme que utilitzarà el simulador per triar una paraula en funció de la dificultat seleccionada
    public static Paraula triaSimulador(FitxerParaulesEntrada diccionari, Fitxa fitxa, int dificultat, boolean idioma) throws Exception {
       int puntuacio = 0;
        int puntuacioSeguent;
        int i = 0;
        
        double resultatParaules;
        
        /*
        En funció de l'idioma (ja que no hi ha la mateixa quantitat de paraules als 2 fitxers) i la dificultat la consola es capaç
        d'elaborar paraules més complexes, i per tant de major puntuació.
        */
        if(idioma) {
            resultatParaules = dificultat/100.0 * 188258.0;
        } else {
            resultatParaules = dificultat/100.0 * 87719.0;
        }
        
        int paraulesCercades = (int) resultatParaules;
        
        Paraula millorParaula = new Paraula();
        Paraula paraulaCercada;   
        
        Fitxa copiaInicialFitxes = new Fitxa();
        copiaInicialFitxes.agafaFitxes(fitxa);
        
        // Segueix el mateix mecanisme que el Cervell Superior però amb un límit preseleccionat 
        while(diccionari.quedenParaules() && i <= paraulesCercades){
      
            paraulaCercada = diccionari.llegeixParaula();

            fitxa.agafaFitxes(copiaInicialFitxes);
            if (paraulaCercada.paraulaValida(fitxa.retornaFitxesUsuari())){
                puntuacioSeguent = fitxa.retornaPunts(paraulaCercada); 

                if(puntuacioSeguent > puntuacio){

                    millorParaula.ompleParaula(paraulaCercada);

                }           
            }  
            
            i++;
        }
        
        
        
        return millorParaula;

    }
       
    
    /*
    * Mètodes no statics de la classe paraula
    */
    
    // Mètode que compara dues paraules i et diu si són iguals.
    public boolean equals(Paraula b) {
        boolean diferencia = false;
        // Si la longitud és diferent, hem trobat una diferència.
        diferencia = (longitud != b.longitud);
        // Per cada lletra, mentre no haguem trobat cap diferència.
        for (int i = 0; i < longitud && !diferencia; i++) {
            // Si les lletres són diferents, hem trobat una diferència.
            diferencia = lletres[i] != b.lletres[i];
        }
        // Retornam si no hem trobat cap diferència.
        return !diferencia;
    }
    
    public void ompleParaula(Paraula paraulaDesitjada){
        longitud = paraulaDesitjada.longitud;
        for (int i = 0; i < longitud; i++) {
            lletres[i] = paraulaDesitjada.lletraA(i);
        }
        
        
    }
    
    
    @Override
    public String toString() {
        // Cream un String resultat.
        String resultat = "";
        // Per cada lletra de la paraula, hi afegim aquell caràcter.
        for (int i = 0; i < longitud; i++) {
            resultat = resultat + lletres[i];
        }
        // Retornam el resultat.
        return resultat;
    }
    
    
    public boolean paraulaValida(char[] fitxes){
        boolean sePotFer = false;
    
        if(longitud <= 11){
            if(estaInclos(fitxes)){
                sePotFer = true;
            }
        }
    
        return sePotFer;
    }   

    
    public boolean estaInclos(char[] fitxes){
        int numCoincidents = 0;
        boolean inclos = false;
        boolean[] trobades = new boolean[11];

        //Cream un array de booleans que ens ajudi a guardar les lletres trobades
        for (int i = 0; i < 11; i++) {
          trobades[i] = false;
        }
        
        //Recorrerm cada lletra de la paraula resposta i la comparam amb totes les lletres de les fitxes disponibles.
        for (int indexParaula = 0; indexParaula < longitud; indexParaula++) {
            int indexFitxes = 0;
            boolean trobat = false;

           while(!trobat){
               /*Si coincideix la lletra de la resposta amb alguna fitxa, es posa un true a l'array de booleans en la mateixa posicio
               i es canvia el valor de la fitxa per '0'.
               */
               if(lletres[indexParaula] == fitxes[indexFitxes]){
                   trobades[indexFitxes] = true;
                   trobat = true;
                   fitxes[indexFitxes] = '0';
               }
               
               //Si arribam al final de les fitxes i no correspon amb cap d'aquestes, finalitzam el recorregut per a aquella posició.
               if(indexFitxes == fitxes.length - 1){
                   trobat = true;
                }

                indexFitxes++;
            }



        }
    
    
    for (int i = 0; i < trobades.length ; i++) {
        if (trobades[i]) {
           numCoincidents++; 
        }
    }
    
    if (numCoincidents == longitud) {
        inclos = true;
    }
    return inclos;
}

    // Mètode que et diu si una paraula té menys longitud de la que es requereix.
    public boolean teCapacitat() {
        return longitud < MAX;
    }

    //Mètode que afegeix una lletra a una paraula.
    public void afegeixLletra(char lletra) {
        lletres[longitud] = lletra;
        longitud++;
    }

    // Mètode que retorna la longitud d'una paraula.
    public int longitud() {
        return longitud;
    }
    
    // Mètode que et retorna una lletra a una posició passada per paràmetre.
    public char lletraA(int posicio) {
        return lletres[posicio];
    }
    
}
