/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scrabble;

/**
 *
 * @authors Sebastià Ballester & Xavier Carbonell
 */
public class Scrabble {

    /**
     * @param args the command line arguments
     */
    
    /*
    * Aquí van les variables globals del programa.
    */
    static boolean idiomaEspañol; 
    static int modeJoc;
    static int dificultat;
    static int jugadors;

    
    
    public static void main(String[] args) {
        

        try {
               
        int operacio;
        boolean surt = false;  
        
        seleccionaIdioma(); //Cridam al subprograma encarregat de seleccionar l'idioma amb el que es desenvoluparà el programa.
        
        presentacio(); //Es crida a la presentació que ens explicarà un poc les normes basiques del joc. 
        
        while (!surt) { // Mentre el jugador no vulgui sortir es demana a aquest la operació que vol realitzar.
            
            FitxerParaulesEntrada mostraHistorial = new FitxerParaulesEntrada("historial.txt");    
            
            if (idiomaEspañol) {

                System.out.println("\n");
                System.out.println("Escribe la operación que quieras realizar: ");
                System.out.print("(Jugar = 1) | (Muestra historial = 2) | (Salir = 3): ");
                operacio = LT.readInt();

                    if (operacio == 1) {

                        triaModeJoc(); //En aquest subprograma es selecciona el mode de joc al que l'usuari vol jugar (Solitari, PVC, PVP)

                        especificaModeJoc(); // Subprograma que depen del mode de joc i indica a quin submode de joc es vol jugar.

                        startGame(); // Aques subprograma s'encarrega de desenvolupar cada partida en funció del mode de joc i el seu submode.

                    } else if (operacio == 2) {

                        mostraHistorial.mostraHistorial(); //Aquest subprograma serveix per si l'usuari vol consultar la llista de partides jugades, puntuacions etc.                
                        mostraHistorial.tanca();
                       
                        
                    } else {

                        System.out.println("\n");
                        System.out.println("Adiós!");
                        surt = true;
                    }

            } else {

                System.out.println("\n");
                System.out.println("Escriu la operació que vulguis realitzar: ");
                System.out.print("(Jugar = 1) | (Mostra historial = 2) | (Sortir = 3): ");
                operacio = LT.readInt();

                if (operacio == 1) {

                    triaModeJoc(); //En aquest subprograma es selecciona el mode de joc al que l'usuari vol jugar (Solitari, PVC, PVP)

                    especificaModeJoc(); // Subprograma que depen del mode de joc i indica a quin submode de joc es vol jugar.

                    startGame(); // Aques subprograma s'encarrega de desenvolupar cada partida en funció del mode de joc i el seu submode.

                } else if (operacio == 2) {

                    mostraHistorial.mostraHistorial(); //Aquest subprograma serveix per si l'usuari vol consultar la llista de partides jugades, puntuacions etc.                
                    
                } else {

                    System.out.println("\n");
                    System.out.println("Adeu!");
                    surt = true;

                }

            }   
            
        }
        
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
    }
    /*
    * Aquí van tots els subprogrames adreçats a la preparació de la partida.
    */

    //Subprograma que fa referència a l'idioma que seleccionarà el jugador. 
    static void seleccionaIdioma(){
        
        char lletraIdioma;
        boolean idiomaTriat = false;
        
        System.out.println("Seleccioni l'idioma amb el que vol jugar." + "\n" + "Seleccione el idioma con el que quiere jugar." + "\n");
        
        //Mentre no s'hagi trïat l'idioma: 
        while(!idiomaTriat){

        //Es demana al jugador en quin idioma vol jugar en funció de la lletra que premi ('c' per Català i 'e' per Espanyol).
        System.out.println("Si vol jugar en Català premi la tecla \"c\"" + "\n" + "Si quiere jugar en Español pulse la tecla \"e\"");
        System.out.print("(c) | (e): ");
        lletraIdioma = LT.readChar();
        
        if(lletraIdioma == 'e'){ //Si el jugador tria la lletra 'e' una variable global prendrà un valor i el programa seguirà en Espanyol.
            System.out.println("Has escogido el idioma \"Español\"." + "\n");
            idiomaEspañol = true;
            idiomaTriat = true;
        }
        else if(lletraIdioma == 'c'){ //En canvi si el jugador tria la lletra 'c' la variable prendrà un altra valor i el programa seguirà en Català.
            System.out.println("Has escogit l'idioma \"Català\"." + "\n");
            idiomaEspañol = false;
            idiomaTriat = true;
            
        }
        //Aquest LT serveix per botar l'intro que s'afageix al pitjar alguna de les opcions disponibles.
        LT.readChar();
        }
    }
    
    //En aquest subprograma es presentarà el joc en un idioma a l'altre en funció de l'idioma seleccionat.
    static void presentacio(){
        
        if(idiomaEspañol){
            System.out.println("Scrabble es un juego donde el/los participantes deberan jugar contra ellos " + "\n" //Presentació en Espanyol.
                             + "o contra una máquina en el que, mediante una serie de rondas, se les daran " + "\n"
                             + "un conjunto de 11 letras aleatorias (cada una con un valor determinado) i deberan formar las mejores " + "\n"
                             + "palabras por tal de obtener la máxima puntuación al final de la partida." + "\n"
                             + "Si la palabra que el participante selecciona no es válida se le aplicarà una penalización de -10 puntos." + "\n"); 
        }else{
            System.out.println("Scrabble és un joc on el/els participants haruan de jugar contra ells " + "\n" //Presentació en Català.
                             + "o contra una màquina en el que, mitjançant una sèrie de rondes, se'ls donaran " + "\n"
                             + "un conjunt de 11 lletres aleatòries (cada una amb un valor determinat) i hauran de formar les millors " + "\n"
                             + "paraules per tal d'obtenir la màxima puntuació al final de la partida." + "\n"
                             + "Si la paraula que el participant selecciona no és vàlida se li aplicarà una penalització de -10 punts." + "\n");
        }
        
    }

    /*
    * Aquí es desenvolupen tots els subprogrmes relacionats amb la trïa de joc
    */

    //En aquest subprograma el jugador triarà  quin mode de joc vol jugar (Un jugador, jugador contra ordinador, multijugador)
    static void triaModeJoc(){
        
        if(idiomaEspañol){
        System.out.println("Qué modo de juego quieres jugar?" + "\n");
        
        System.out.println("1 jugador (1)");
        System.out.println("Jugador vs Ordenador (2)");
        System.out.println("Jugador vs Jugador (3)" + "\n");
        
        System.out.print("Pulsa la tecla del modo que quieras jugar: ");
        modeJoc = LT.readInt();
        System.out.println("\n");
       
        }
        else{
        System.out.println("Quin mode de joc vols jugar?" + "\n");
        System.out.println("1 jugador (1)");
        System.out.println("Jugador vs Ordinador (2)");
        System.out.println("Jugador vs Jugador (3)" + "\n");
        
        System.out.print("Escriu la tecla del mode que vulguis jugar: ");
        modeJoc = LT.readInt();
        System.out.println("\n");
        
        //Suposant que el jugador no pot pitjar una tecla que no sigui 1,2 o 3, la variable modeJoc variarà en funció de la tecla seleccionada per l'usuari
        
        }
    }
    
    //En aquest subprograma s'especificarà el mode de joc anteriorment seleccionat:
    static void especificaModeJoc(){
        
        //Aquí s'especifica el mode de joc en espanyol
        if(idiomaEspañol && modeJoc == 1){
            System.out.println("Empecemos la partida!"); //Si s'ha escollit el mode 1 jugador la partida pot començar directament
        } else if(idiomaEspañol && modeJoc == 2){
            System.out.println("Elija dificultad: Cerebro Superior (1) o Simulador (2)."); //Si s'ha escollit el mode Jugador vs Ordinador s'ha de triar entre el mode cervell superior o el simulador
            System.out.print("(1) | (2): ");
            dificultat = LT.readInt();
            System.out.println("Empecemos la partida!");
        }else if(idiomaEspañol && modeJoc == 3){
            System.out.println("¿Cuántos jugadores serán? (Entre 2-4). "); //Si s'ha escollit el mode multijugador s'han de triar les persones que jugaran (entre 2 i 4).
            System.out.print("(2) | (3) | (4): ");
            jugadors = LT.readInt();
            System.out.println("Empecemos la partida!");
            
        //Aquí s'especifica el mode de joc en català    
        }else if(!idiomaEspañol && modeJoc == 1){
            System.out.println("Comencem el joc!");
        }else if(!idiomaEspañol && modeJoc == 2){
            System.out.println("Tria la dificultat: Cervell Superior (1) o Simulador (2).");
            System.out.print("(1) | (2): ");
            dificultat = LT.readInt();
            System.out.println("Comencem el joc!");
        }else if(!idiomaEspañol && modeJoc == 3){
            System.out.println("Quants de jugadors sou? (Entre 2-4). ");
            System.out.print("(2) | (3) | (4): ");
            jugadors = LT.readInt();
            System.out.println("Comencem el joc!");
        }
    }
    
    
   /*
    * En aquest subprograma es durà a terme el desenvolupament de caca joc.
    */
    
    static void startGame() throws Exception {
        
        FitxerParaulesSortida historial = new FitxerParaulesSortida("historial.txt", true);
        
        switch (modeJoc) { //Cream un switch on cada cas serà el mode de joc seleccionat.
            
            //Aquí es durà a terme el mode de joc 'solitari'.
            case 1:
                
                /*
                * Aquí es declaren les variables que s'utilitzaran per dur a terme el solitari.
                */
                boolean contestat = false, jugarRonda = true;
                char resposta;
                int numRondasSolitari, rondaActual = 1, puntuacio = 0, puntsGuanyats = 0;
                
                Paraula nomJugadorSol = new Paraula();
                
                if (idiomaEspañol) { //En aquest if es desenvolupa el solitari en 'Espanyol'.
                    
                    System.out.print("Introduce tu nombre: ");
                    nomJugadorSol = Paraula.llegeix();
                    
                    System.out.print("Teclea el número de rondas que quieres jugar: ");
                    numRondasSolitari = LT.readInt(); //Aquí l'usuari trïa el número de rondes que vol jugar
                          
                    //Com l'idioma es l'espanyol s'analitzarà el fitxer diccionari en Espanyol.
                    FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("esp.dic");
                
                    
                    for (int contadorRondes = 0; contadorRondes < numRondasSolitari; contadorRondes++) { //Es crea un for en el que s'anirà produint cada ronda en funció del num. de rondes escogides.
                        
                        System.out.println("Ronda #" + rondaActual);
                    
                        // Cridam la classe que ens omplirà el sac de fitxes i seleccionarà 11 fitxes aleatòries per al jugador.
                        Fitxa solitari = new Fitxa();

                        System.out.println("Crea una palabra con las siguientes fichas: ");

                        solitari.mostraFitxesUsuari(); //Es mostren les 11 fitxes al jugador.
                        System.out.println("\n");
                      
                    
                        System.out.print("Escribe la palabra: "); //Aques escriu la paraula que cregui oportuna.
                        Paraula paraulaResposta = Paraula.llegeix();
                    
                        //Si la paraula és vàlida i està inclosa al diccionari el jugador guanya els punts corresponents i se li acumulen a la seva puntuació.
                        if(paraulaResposta.paraulaValida(solitari.retornaFitxesUsuari()) && estaInclosEspañol(paraulaResposta)){
                            System.out.println("Válida" + '\n');
                            puntsGuanyats =solitari.retornaPunts(paraulaResposta);
                            System.out.println("Puntos ganados: " + puntsGuanyats);
                            
                            puntuacio += puntsGuanyats;
                            System.out.println("Total: "+ puntuacio + " puntos.");
                            
                        } else{ //Sinó el jugador té una penalització de -10 punts que se li acumulen a la seva puntuació.
                            System.out.println("No válida. -10 puntos" + '\n');
                            puntuacio -= 10;
                            System.out.println("Total: "+ puntuacio + " puntos.");
                        
                        } 
                        
                        rondaActual++; //Quan acaba la ronda se li suma una unitat al marcador de rondes.
                        System.out.println("\n");
                    
                    }
                
                    System.out.println("La partida ha terminado!");
                    System.out.println("Tu puntuación es " + puntuacio + ".");
                      
                    
                } else { //A l'else corresponent del primer if es produirà el mateix però en 'Català'.
                    
                    //Aquest següeix el mateix mecanisme que el fet en Espanyol però en l'idioma Català.
                    
                    System.out.print("Intrdueix el teu nom: ");
                    nomJugadorSol = Paraula.llegeix();
                    
                    
                    System.out.print("Escriu el nombre de rondes que vulguis jugar: ");
                    numRondasSolitari = LT.readInt();
                    
                    //L'únic que canvia en aquest és que s'analitza el fitxer diccionari en Català.
                    FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("cat.dic");
                
                    for (int contadorRondes = 0; contadorRondes < numRondasSolitari; contadorRondes++) {
                        
                        System.out.println("Ronda #" + rondaActual);
                    
                        Fitxa solitari = new Fitxa();

                        System.out.println("Crea una paraula amb les següents fitxes: ");

                        solitari.mostraFitxesUsuari();
                        System.out.println("\n");
                      
                    
                        System.out.print("Escriu la paraula: ");
                        Paraula paraulaResposta = Paraula.llegeix();
                    
                        if(paraulaResposta.paraulaValida(solitari.retornaFitxesUsuari()) && estaInclosCatala(paraulaResposta)){
                            System.out.println("Vàlida" + '\n');
                            puntsGuanyats =solitari.retornaPunts(paraulaResposta);
                            System.out.println("Punts guanyats: " + puntsGuanyats);
                            
                            puntuacio += puntsGuanyats;
                            System.out.println("Total: "+ puntuacio + " punts.");
                        } else{
                            System.out.println("No válida. -10 punts" + '\n');
                            puntuacio -= 10;
                            System.out.println("Total: "+ puntuacio + " punts.");
                        
                        } 
                        
                        rondaActual++;
                        System.out.println("\n");
                        
                    }
                
                    System.out.println("La partida ha acabat!");
                    System.out.println("La teva puntuació és " + puntuacio + ".");
                    
                }
                
                historial.escriuHistorialSolitari(nomJugadorSol, puntuacio, idiomaEspañol); 
                
                break;
     
            //Aquí es durà a terme el mode de joc 'Jugador vs Consola (PVC)'.
            case 2:
                
                int numRondesPVC, rondaActualPVC = 1, puntuacioJugador = 0, puntuacioMaquina = 0;
                int dificultatSimulador;
                Paraula nomJugadorPVC = new Paraula();
                
                if (dificultat == 1) {
                    
                    //Aquí es desenvoluparà el mode de joc Cervell Superior
                    
                    if (idiomaEspañol) {
                        
                    //Aquí es desenvolupa el Cervell Superior en Espanyol
                    
                    System.out.print("Introduce tu nombre: ");
                    nomJugadorPVC = Paraula.llegeix();
                    
                    System.out.print("Selecciona el número de rondas que quieres jugar: "); //Aquí l'usuari trïa les rondes que vol jugar en aquesta partida.
                    numRondesPVC = LT.readInt();
                    
                    for (int i = 0; i < numRondesPVC; i++) { //Es crea un for en el que s'anirà produint cada ronda en funció del num. de rondes escogides.
                        
                        FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("esp.dic"); //Com escogim l'idioma Espanyol s'analitzarà el fitxer corresponent
                        
                        System.out.println("\n");
                        System.out.println("Ronda #" + rondaActualPVC);
                        
                        //Comença a jugar el Jugador 1.
                        System.out.println("\n");
                        System.out.println("Turno de " + nomJugadorPVC + ":" + "\n");

                        Fitxa PVC = new Fitxa();

                        System.out.println("Crea una palabra con las siguientes fichas: ");

                        PVC.mostraFitxesUsuari(); //Es donen un conjunt de 11 fitxes aleaotires al jugador 1.
                        System.out.println("\n");
                      
                        System.out.print("Escribe la palabra: "); //El jugador 1 escriu una paraula.
                        Paraula paraulaRespostaJ1 = Paraula.llegeix();
                    
                        //Si la paraula és vàlida i està inclosa al diccionari el jugador guanya els punts corresponents i se li acumulen a la seva puntuació.
                        if(paraulaRespostaJ1.paraulaValida(PVC.retornaFitxesUsuari()) && estaInclosEspañol(paraulaRespostaJ1)){
                            System.out.println("Válida" + "\n");
                            puntsGuanyats =PVC.retornaPunts(paraulaRespostaJ1);
                            System.out.println("Puntos ganados: " + puntsGuanyats + "\n");
                            
                            puntuacioJugador += puntsGuanyats;
                            System.out.println("Total: "+ puntuacioJugador + " puntos.");
                            
                        } else{ //Si la paraula no és vàlida o no està inclosa al diccionari es penalitza al jugador amb -10 punts i se li acumulen a la seva puntuació.
                            System.out.println("No válida. -10 puntos");
                            puntuacioJugador -= 10;
                            System.out.println("Total: "+ puntuacioJugador + " puntos." + "\n");
                        
                        } 
                        
                        /*
                        * El mecanisme del primer jugador es repeteix a cada jugador de la partida.
                        */
                        
                        // Comença a jugar el Jugador 2.
                        System.out.println("\n");
                        System.out.println("Turno de la consola: ");
                        
                        PVC.creaNovesFitxes();
                        System.out.println("Crea una palabra con las siguientes fichas: ");

                        PVC.mostraFitxesUsuari();
                        System.out.println("\n");
                      
                    
                        System.out.print("Escribe la palabra: ");
                        Paraula paraulaRespostaMaquina = Paraula.triaMillorParaula(diccionario, PVC);
                        System.out.println(paraulaRespostaMaquina);
                    

                        System.out.println("Válida" + '\n');
                        puntsGuanyats =PVC.retornaPunts(paraulaRespostaMaquina);
                        System.out.println("Puntos ganados: " + puntsGuanyats);
                        puntuacioMaquina += puntsGuanyats;
                        System.out.println("Total: " + puntuacioMaquina + " puntos." + "\n");
                            
                        rondaActualPVC++;
                            
                    }
                    
                        System.out.println("La partida ha terminado!");
                        if (puntuacioMaquina > puntuacioJugador) {
                            System.out.println("El ganador es la consola con " + puntuacioMaquina + " puntos.");
                        } else if (puntuacioMaquina < puntuacioJugador) {
                            System.out.println("El ganador es '" + nomJugadorPVC + "' con " + puntuacioJugador + " puntos.");
                        } else {
                            System.out.println("El jugador '" + nomJugadorPVC + "' y la consola han empatado con " + puntuacioJugador + " puntos.");                            
                        }
                        
                        
                    } else {
                        
                    //Aquí es desenvolupa el Cervell Superior en Català
                    
                    System.out.print("Intrdueix el teu nom: ");
                    nomJugadorPVC = Paraula.llegeix();
                        
                    System.out.print("Selecciona el nombre de rondes que vols jugar: "); //Aquí l'usuari trïa les rondes que vol jugar en aquesta partida.
                    numRondesPVC = LT.readInt();
                    
                    for (int i = 0; i < numRondesPVC; i++) { //Es crea un for en el que s'anirà produint cada ronda en funció del num. de rondes escogides.
                        
                        FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("cat.dic"); //Com escogim l'idioma Espanyol s'analitzarà el fitxer corresponent
                        
                        System.out.println("\n");
                        System.out.println("Ronda #" + rondaActualPVC);
                        
                        //Comença a jugar el Jugador 1.
                        System.out.println("\n");
                        System.out.println("Torn de " + nomJugadorPVC + ": " +  "\n");

                        Fitxa PVC = new Fitxa();

                        System.out.println("Crea una paraula amb les següents fitxes: ");

                        PVC.mostraFitxesUsuari(); //Es donen un conjunt de 11 fitxes aleaotires al jugador 1.
                        System.out.println("\n");
                      
                        System.out.print("Escriu la paraula: "); //El jugador 1 escriu una paraula.
                        Paraula paraulaRespostaJ1 = Paraula.llegeix();
                    
                        //Si la paraula és vàlida i està inclosa al diccionari el jugador guanya els punts corresponents i se li acumulen a la seva puntuació.
                        if(paraulaRespostaJ1.paraulaValida(PVC.retornaFitxesUsuari()) && estaInclosCatala(paraulaRespostaJ1)){
                            System.out.println("Vàlida" + "\n");
                            puntsGuanyats =PVC.retornaPunts(paraulaRespostaJ1);
                            System.out.println("Punts guanyats: " + puntsGuanyats + "\n");
                            
                            puntuacioJugador += puntsGuanyats;
                            System.out.println("Total: "+ puntuacioJugador + " punts.");
                            
                        } else{ //Si la paraula no és vàlida o no està inclosa al diccionari es penalitza al jugador amb -10 punts i se li acumulen a la seva puntuació.
                            System.out.println("No vàlida. -10 puntos");
                            puntuacioJugador -= 10;
                            System.out.println("Total: "+ puntuacioJugador + " punts." + "\n");
                        
                        } 
                        
                        // Comença a jugar la consola
                        System.out.println("\n");
                        System.out.println("Torn de la consola: ");
                        
                        PVC.creaNovesFitxes();
                        System.out.println("Crea una paraula amb les següents fitxes: ");

                        PVC.mostraFitxesUsuari();
                        System.out.println("\n");
                      
                        System.out.print("Escriu la paraula: ");
                        Paraula paraulaRespostaMaquina = Paraula.triaMillorParaula(diccionario, PVC);
                        System.out.println(paraulaRespostaMaquina); //Aquesta analitza el diccionari amb les seves fitxes i trïa la paraula amb major puntuació.
                    
                        System.out.println("Vàlida" + '\n');
                        puntsGuanyats =PVC.retornaPunts(paraulaRespostaMaquina);
                        System.out.println("Puntos guanyats: " + puntsGuanyats);
                        puntuacioMaquina += puntsGuanyats;
                        System.out.println("Total: " + puntuacioMaquina + " punts." + "\n");
                            
                        rondaActualPVC++;
                            
                    }
                    
                        System.out.println("La partida ha acabat!");
                        if (puntuacioMaquina > puntuacioJugador) {
                            System.out.println("El guanyador és la consola amb " + puntuacioMaquina + " punts.");
                        } else if (puntuacioMaquina < puntuacioJugador) {
                            System.out.println("El guanyador és '" + nomJugadorPVC + "' amb " + puntuacioJugador + " punts.");
                        } else {
                            System.out.println("El jugador '" + nomJugadorPVC + "' i la consola han empatat amb " + puntuacioJugador + " punts.");
                        }
                         
                    }
                    
                } else {
                    
                    //Aquí es desenvoluparà el mode de joc Simulador
                    
                    
                    if (idiomaEspañol) {
                        
                    System.out.print("Introduce tu nombre: ");
                    nomJugadorPVC = Paraula.llegeix();
                    
                    System.out.print("Selecciona el número de rondas que quieres jugar: "); //Aquí l'usuari trïa les rondes que vol jugar en aquesta partida.
                    numRondesPVC = LT.readInt();
                    
                     System.out.print("Selecciona el nivel de dificultat del Simulador (1-100): ");
                     dificultatSimulador = LT.readInt();
                    
                    for (int i = 0; i < numRondesPVC; i++) { //Es crea un for en el que s'anirà produint cada ronda en funció del num. de rondes escogides.
                        
                        FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("esp.dic"); //Com escogim l'idioma Espanyol s'analitzarà el fitxer corresponent
                        
                        System.out.println("\n");
                        System.out.println("Ronda #" + rondaActualPVC);
                        
                        //Comença a jugar el Jugador 1.
                        System.out.println("\n");
                        System.out.println("Turno de " + nomJugadorPVC + ":" + "\n");

                        Fitxa PVC = new Fitxa();

                        System.out.println("Crea una palabra con las siguientes fichas: ");

                        PVC.mostraFitxesUsuari(); //Es donen un conjunt de 11 fitxes aleaotires al jugador 1.
                        System.out.println("\n");
                      
                        System.out.print("Escribe la palabra: "); //El jugador 1 escriu una paraula.
                        Paraula paraulaRespostaJ1 = Paraula.llegeix();
                    
                        //Si la paraula és vàlida i està inclosa al diccionari el jugador guanya els punts corresponents i se li acumulen a la seva puntuació.
                        if(paraulaRespostaJ1.paraulaValida(PVC.retornaFitxesUsuari()) && estaInclosEspañol(paraulaRespostaJ1)){
                            System.out.println("Válida" + "\n");
                            puntsGuanyats =PVC.retornaPunts(paraulaRespostaJ1);
                            System.out.println("Puntos ganados: " + puntsGuanyats + "\n");
                            
                            puntuacioJugador += puntsGuanyats;
                            System.out.println("Total: "+ puntuacioJugador + " puntos.");
                            
                        } else{ //Si la paraula no és vàlida o no està inclosa al diccionari es penalitza al jugador amb -10 punts i se li acumulen a la seva puntuació.
                            System.out.println("No válida. -10 puntos");
                            puntuacioJugador -= 10;
                            System.out.println("Total: "+ puntuacioJugador + " puntos." + "\n");
                        
                        } 
                       
                        // Comença a jugar el Simulador.
                        System.out.println("\n");
                        System.out.println("Turno de la consola: ");
                        
                        PVC.creaNovesFitxes();
                        System.out.println("Crea una palabra con las siguientes fichas: ");

                        PVC.mostraFitxesUsuari();
                        System.out.println("\n");
                      
                    
                        System.out.print("Escribe la palabra: ");
                        Paraula paraulaRespostaMaquina = Paraula.triaSimulador(diccionario, PVC, dificultatSimulador, idiomaEspañol);
                        System.out.println(paraulaRespostaMaquina);
                    

                        System.out.println("Válida" + '\n');
                        puntsGuanyats =PVC.retornaPunts(paraulaRespostaMaquina);
                        System.out.println("Puntos ganados: " + puntsGuanyats);
                        puntuacioMaquina += puntsGuanyats;
                        System.out.println("Total: " + puntuacioMaquina + " puntos." + "\n");
                            
                        rondaActualPVC++;
                            
                    }
                    
                        System.out.println("La partida ha terminado!");
                        if (puntuacioMaquina > puntuacioJugador) {
                            System.out.println("El ganador es la consola con " + puntuacioMaquina + " puntos.");
                        } else if (puntuacioMaquina < puntuacioJugador) {
                            System.out.println("El ganador es '" + nomJugadorPVC + "' con " + puntuacioJugador + " puntos.");
                        } else {
                            System.out.println("El jugador '" + nomJugadorPVC + "' i la consola han empatado con " + puntuacioJugador + " puntos.");                            
                        }
                         
                        
                    }else{ // Aquí va en català
                        
                        System.out.print("Introdueix el teu nom: ");
                        nomJugadorPVC = Paraula.llegeix();

                        System.out.print("Selecciona el número de rondes que vols jugar: "); //Aquí l'usuari trïa les rondes que vol jugar en aquesta partida.
                        numRondesPVC = LT.readInt();

                         System.out.print("Selecciona el nivell de dificultat del Simulador (1-100): ");
                         dificultatSimulador = LT.readInt();

                        for (int i = 0; i < numRondesPVC; i++) { //Es crea un for en el que s'anirà produint cada ronda en funció del num. de rondes escogides.

                            FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("cat.dic"); //Com escogim l'idioma Espanyol s'analitzarà el fitxer corresponent

                            System.out.println("\n");
                            System.out.println("Ronda #" + rondaActualPVC);

                            //Comença a jugar el Jugador 1.
                            System.out.println("\n");
                            System.out.println("Torn de " + nomJugadorPVC + ": " + "\n");

                            Fitxa PVC = new Fitxa();

                            System.out.println("Crea una paraula amb les següents fitxes: ");

                            PVC.mostraFitxesUsuari(); //Es donen un conjunt de 11 fitxes aleaotires al jugador 1.
                            System.out.println("\n");

                            System.out.print("Escriu la paraula: "); //El jugador 1 escriu una paraula.
                            Paraula paraulaRespostaJ1 = Paraula.llegeix();

                            //Si la paraula és vàlida i està inclosa al diccionari el jugador guanya els punts corresponents i se li acumulen a la seva puntuació.
                            if(paraulaRespostaJ1.paraulaValida(PVC.retornaFitxesUsuari()) && estaInclosEspañol(paraulaRespostaJ1)){
                                System.out.println("Vàlida" + "\n");
                                puntsGuanyats =PVC.retornaPunts(paraulaRespostaJ1);
                                System.out.println("Punts guanyats: " + puntsGuanyats + "\n");

                                puntuacioJugador += puntsGuanyats;
                                System.out.println("Total: "+ puntuacioJugador + " punts.");

                            } else{ //Si la paraula no és vàlida o no està inclosa al diccionari es penalitza al jugador amb -10 punts i se li acumulen a la seva puntuació.
                                System.out.println("No vàlida. -10 puntos");
                                puntuacioJugador -= 10;
                                System.out.println("Total: "+ puntuacioJugador + " punts." + "\n");

                            } 

                            /*
                            * El mecanisme del primer jugador es repeteix a cada jugador de la partida.
                            */

                            // Comença a jugar el Simulador.
                            System.out.println("\n");
                            System.out.println("Torn de la consola: ");

                            PVC.creaNovesFitxes();
                            System.out.println("Crea una paraula amb les següents fitxes: ");

                            PVC.mostraFitxesUsuari();
                            System.out.println("\n");


                            System.out.print("Escriu la paraula: ");
                            Paraula paraulaRespostaMaquina = Paraula.triaSimulador(diccionario, PVC, dificultatSimulador, idiomaEspañol);
                            System.out.println(paraulaRespostaMaquina);


                            System.out.println("Vàlida" + '\n');
                            puntsGuanyats =PVC.retornaPunts(paraulaRespostaMaquina);
                            System.out.println("Punts guanyats: " + puntsGuanyats);
                            puntuacioMaquina += puntsGuanyats;
                            System.out.println("Total: " + puntuacioMaquina + " punts." + "\n");

                            rondaActualPVC++;

                        }

                            System.out.println("La partida ha acabat!");
                            if (puntuacioMaquina > puntuacioJugador) {
                                System.out.println("El guanyador és la consola amb " + puntuacioMaquina + " punts.");
                            } else if (puntuacioMaquina < puntuacioJugador) {
                                System.out.println("El guanyador és '" + nomJugadorPVC + "' amb " + puntuacioJugador + " punts.");
                            } else {
                                System.out.println("El jugador '" + nomJugadorPVC + "' i la consola han empatat amb " + puntuacioJugador + " punts.");                            
                            }

                        }

                    }
                
                historial.escriuHistorialPVC(nomJugadorPVC, dificultat, puntuacioJugador, puntuacioMaquina, idiomaEspañol);
                                 
                break;
                
            // Aquí es durà a terme el mode de joc 'Jugador vs Jugador (PVP)'.
            case 3:
                
                /*
                * Aquí declaram les variables que ens ajugaran a desenvolupar aquest mode de joc.
                */
                int numRondesPVP, rondaActualPVP = 1;   
                int puntuacioJ1 = 0, puntuacioJ2 = 0, puntuacioJ3 = 0, puntuacioJ4 = 0;
                int puntuacioGuanyadora;
                
                Paraula nomJugador1 = new Paraula();
                Paraula nomJugador2 = new Paraula();
                Paraula nomJugador3 = new Paraula();
                Paraula nomJugador4 = new Paraula();
                Paraula nomGuanyador = new Paraula();
                
                if (idiomaEspañol) { //Aquí es desenvolupa el PVP en l'idioma Espanyol.

                    FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("esp.dic"); //Com escogim l'idioma Espanyol s'analitzarà el fitxer corresponent
                    
                    //Aquí cada jugador posarà el seu nom
                    System.out.print("Jugador 1, introduce tu nombre: ");
                    nomJugador1 = Paraula.llegeix();
                    System.out.print("Jugador 2, introduce tu nombre: ");
                    nomJugador2 = Paraula.llegeix();
                    if (jugadors == 3 || jugadors == 4) {
                        System.out.print("Jugador 3, introduce tu nombre: ");
                        nomJugador3 = Paraula.llegeix();
                    }
                    if (jugadors == 4) {
                        System.out.print("Jugador 4, introduce tu nombre: ");
                        nomJugador4 = Paraula.llegeix();
                    }
                    
                    System.out.print("Seleccionad el número de rondas que quereis jugar: "); //Aquí l'usuari trïa les rondes que vol jugar en aquesta partida.
                    numRondesPVP = LT.readInt();
                    
                    for (int i = 0; i < numRondesPVP; i++) { //Es crea un for en el que s'anirà produint cada ronda en funció del num. de rondes escogides.
                        
                        System.out.println("Ronda #" + rondaActualPVP);
                        
                        //Comença a jugar el Jugador 1.
                        System.out.println("\n");
                        System.out.println("Turno de '" + nomJugador1 + "': " + "\n");

                        Fitxa PVP = new Fitxa();

                        System.out.println("Crea una palabra con las siguientes fichas: ");

                        PVP.mostraFitxesUsuari(); //Es donen un conjunt de 11 fitxes aleaotires al jugador 1.
                        System.out.println("\n");
                      
                        System.out.print("Escribe la palabra: "); //El jugador 1 escriu una paraula.
                        Paraula paraulaRespostaJ1 = Paraula.llegeix();
                    
                        //Si la paraula és vàlida i està inclosa al diccionari el jugador guanya els punts corresponents i se li acumulen a la seva puntuació.
                        if(paraulaRespostaJ1.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosEspañol(paraulaRespostaJ1)){
                            System.out.println("Válida");
                            puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ1);
                            System.out.println("Puntos ganados: " + puntsGuanyats + "\n");
                            
                            puntuacioJ1 += puntsGuanyats;
                            System.out.println("Total : "+ puntuacioJ1 + " puntos.");
                            
                        } else{ //Si la paraula no és vàlida o no està inclosa al diccionari es penalitza al jugador amb -10 punts i se li acumulen a la seva puntuació.
                            System.out.println("No válida. -10 puntos");
                            puntuacioJ1 -= 10;
                            System.out.println("Total : "+ puntuacioJ1 + " puntos." + "\n");
                        
                        } 
                        
                        /*
                        * El mecanisme del primer jugador es repeteix a cada jugador de la partida.
                        */
                        
                        // Comença a jugar el Jugador 2.
                        System.out.println("\n");
                        System.out.println("Turno de '" + nomJugador2 + "': ");
                        
                        PVP.creaNovesFitxes();
                        System.out.println("Crea una palabra con las siguientes fichas: ");

                        PVP.mostraFitxesUsuari();
                        System.out.println("\n");
                      
                    
                        System.out.print("Escribe la palabra: ");
                        Paraula paraulaRespostaJ2 = Paraula.llegeix();
                    
                        if(paraulaRespostaJ2.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosEspañol(paraulaRespostaJ2)){
                            System.out.println("Válida" + '\n');
                            puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ2);
                            System.out.println("Puntos ganados: " + puntsGuanyats);
                            
                            puntuacioJ2 += puntsGuanyats;
                            System.out.println("Total : "+ puntuacioJ2 + " puntos.");
                        } else{
                            System.out.println("No válida. -10 puntos" + '\n');
                            puntuacioJ2 -= 10;
                            System.out.println("Total : "+ puntuacioJ2 + " puntos.");
                        
                        } 

                        //Si ha triat 3 jugadors o 4, el jugador 3 comença a jugar.
                        if(jugadors == 3 || jugadors == 4){
                            System.out.println("\n");
                            System.out.println("Turno de '" + nomJugador3 + "': ");
                        
                            PVP.creaNovesFitxes();
                            System.out.println("Crea una palabra con las siguientes fichas: ");

                            PVP.mostraFitxesUsuari();          
                            
                            System.out.println("\n");
                            System.out.print("Escribe la palabra: ");
                            Paraula paraulaRespostaJ3 = Paraula.llegeix();
                    
                            if(paraulaRespostaJ3.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosEspañol(paraulaRespostaJ3)){
                                System.out.println("Válida");
                                puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ3);
                                System.out.println("Puntos ganados: " + puntsGuanyats);
                            
                                puntuacioJ3 += puntsGuanyats;
                                System.out.println("Total: "+ puntuacioJ3 + " puntos.");
                                
                            } else{
                                System.out.println("No válida. -10 puntos");
                                puntuacioJ3 -= 10;
                                System.out.println("Total: "+ puntuacioJ3 + " puntos.");
                        
                            } 
                        }
                        
                        //Si s'han escogit 4 jugadors, el jugador 4 comença a jugar.
                        if(jugadors == 4){
                            
                            System.out.println("\n");
                            System.out.println("Turno de '" + nomJugador4 + "': ");
                            PVP.creaNovesFitxes();
                            System.out.println("Crea una palabra con las siguientes fichas: ");

                            PVP.mostraFitxesUsuari();
                    
                            System.out.println("\n");
                            System.out.print("Escribe la palabra: ");
                            Paraula paraulaRespostaJ4 = Paraula.llegeix();
                    
                            if(paraulaRespostaJ4.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosEspañol(paraulaRespostaJ4)){
                                System.out.println("Válida");
                                puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ4);
                                System.out.println("Puntos ganados: " + puntsGuanyats);
                            
                                puntuacioJ4 += puntsGuanyats;
                                System.out.println("Total: "+ puntuacioJ4 + " puntos.");
                                
                            } else{
                                System.out.println("No válida. -10 puntos");
                                puntuacioJ4 -= 10;
                                System.out.println("Total: "+ puntuacioJ4 + " puntos." + "\n");
                        
                            }
                        }
                        
                        rondaActualPVP++; // Quan s'han acabat els torn de tots els jugadors de la ronda, se li suma una unitat al marcador de rondes.
                        System.out.println("\n");
                    }
                    
                    //Es mostra qui és el guanyador de la partida
                    System.out.println("La partida ha terminado!");                    
                   if (jugadors == 2) {
                        
                        if (puntuacioJ1 > puntuacioJ2) {
                            System.out.println("El ganador es '" + nomJugador1 + "' con " + puntuacioJ1 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ1;
                            nomGuanyador.ompleParaula(nomJugador1);
                        } else if(puntuacioJ1 > puntuacioJ1) {
                            System.out.println("El ganador es '" + nomJugador2 + "' con " + puntuacioJ2 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ2;
                            nomGuanyador.ompleParaula(nomJugador2);

                        } else{
                            System.out.println("Empate!");
                            puntuacioGuanyadora = -300;
                        }
                        
                    } else if (jugadors == 3) {
                        
                        if (puntuacioJ3 > puntuacioJ1 && puntuacioJ3 > puntuacioJ2) {
                            System.out.println("El ganador es '" + nomJugador3 + "' con " + puntuacioJ3 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ3;
                            nomGuanyador.ompleParaula(nomJugador3);

                        } else if (puntuacioJ2 > puntuacioJ1 && puntuacioJ2 > puntuacioJ3) {
                            System.out.println("El ganador es '" + nomJugador2 + "' con " + puntuacioJ2 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ2;
                            nomGuanyador.ompleParaula(nomJugador2);                            
                        } else if(puntuacioJ1 > puntuacioJ2 && puntuacioJ1 > puntuacioJ3) {
                            System.out.println("El ganador es '" + nomJugador1 + "' con " + puntuacioJ1 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ1;
                            nomGuanyador.ompleParaula(nomJugador1);                            
                        } else{
                            
                            System.out.println("Empate!");
                            puntuacioGuanyadora = -300;
                            
                        }
                        
                    } else {
                        
                        if (puntuacioJ4 > puntuacioJ1 && puntuacioJ4 > puntuacioJ2 && puntuacioJ4 > puntuacioJ3) {
                            System.out.println("El ganador es '" + nomJugador4 + "' con " + puntuacioJ4 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ4;
                            nomGuanyador.ompleParaula(nomJugador4);                            
                        } else if (puntuacioJ3 > puntuacioJ1 && puntuacioJ3 > puntuacioJ2 && puntuacioJ3 > puntuacioJ4) {
                            System.out.println("El ganador es '" + nomJugador3 + "' con " + puntuacioJ3 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ3;
                            nomGuanyador.ompleParaula(nomJugador3);                            
                        } else if (puntuacioJ2 > puntuacioJ1 && puntuacioJ2 > puntuacioJ3 && puntuacioJ2 > puntuacioJ4) {
                            System.out.println("El ganador es '" + nomJugador2 + "' con " + puntuacioJ2 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ2;
                            nomGuanyador.ompleParaula(nomJugador2);                            
                        } else if (puntuacioJ1 > puntuacioJ2 && puntuacioJ1 > puntuacioJ3 && puntuacioJ1 > puntuacioJ4){
                            System.out.println("El ganador es '" + nomJugador1 + "' con " + puntuacioJ1 + " puntos.");
                            puntuacioGuanyadora = puntuacioJ1;
                            nomGuanyador.ompleParaula(nomJugador1);                            
                        }
                        else{
                            System.out.println("Empate!");
                            puntuacioGuanyadora = -300;
                        }
                    }
                    
                    
                } else { //Aquí es desenvolupa el mode de joc PVP en Català.
                    
                    FitxerParaulesEntrada diccionario = new FitxerParaulesEntrada("cat.dic"); //Com escogim l'idioma Català s'analitzarà el fitxer corresponent
                    
                    //Aquí cada jugador posarà el seu nom
                    System.out.print("Jugador 1, introdueix el teu nom: ");
                    nomJugador1 = Paraula.llegeix();
                    System.out.print("Jugador 2, introdueix el teu nom: ");
                    nomJugador2 = Paraula.llegeix();
                    if (jugadors == 3 || jugadors == 4) {
                        System.out.print("Jugador 3, introdueix el teu nom: ");
                        nomJugador3 = Paraula.llegeix();
                    }
                    if (jugadors == 4) {
                        System.out.print("Jugador 4, introdueix el teu nom: ");
                        nomJugador4 = Paraula.llegeix();
                    }
                    
                    
                    System.out.print("Seleccionau el número de rondes que voleu jugar: "); //Aquí l'usuari trïa les rondes que vol jugar en aquesta partida.
                    numRondesPVP = LT.readInt();
                    
                    for (int i = 0; i < numRondesPVP; i++) { //Es crea un for en el que s'anirà produint cada ronda en funció del num. de rondes escogides.
                        
                        System.out.println("Ronda #" + rondaActualPVP);
                        
                        //Comença a jugar el Jugador 1.
                        System.out.println("\n");
                        System.out.println("Torn de '" + nomJugador1 + "'." + "\n");

                        Fitxa PVP = new Fitxa();

                        System.out.println("Crea una paraula amb les següents fitxes: ");

                        PVP.mostraFitxesUsuari(); //Es donen un conjunt de 11 fitxes aleaotires al jugador 1.
                        System.out.println("\n");
                      
                        System.out.print("Escriu la paraula: "); //El jugador 1 escriu una paraula.
                        Paraula paraulaRespostaJ1 = Paraula.llegeix();
                    
                        //Si la paraula és vàlida i està inclosa al diccionari el jugador guanya els punts corresponents i se li acumulen a la seva puntuació.
                        if(paraulaRespostaJ1.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosCatala(paraulaRespostaJ1)){
                            System.out.println("Vàlida");
                            puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ1);
                            System.out.println("Punts guanyats: " + puntsGuanyats);
                            
                            puntuacioJ1 += puntsGuanyats;
                            System.out.println("Total: "+ puntuacioJ1 + " punts.");
                            
                        } else{ //Si la paraula no és vàlida o no està inclosa al diccionari es penalitza al jugador amb -10 punts i se li acumulen a la seva puntuació.
                            System.out.println("No vàlida. -10 punts");
                            puntuacioJ1 -= 10;
                            System.out.println("Total: "+ puntuacioJ1 + " punts.");
                        
                        } 
                        
                        /*
                        * El mecanisme del primer jugador es repeteix a cada jugador de la partida.
                        */
                        
                        // Comença a jugar el Jugador 2.
                        System.out.println("\n");
                        System.out.println("Torn de '" + nomJugador2 + "'." + "\n");
                        
                        PVP.creaNovesFitxes();
                        System.out.println("Crea una paraula amb les següents fitxes: ");

                        PVP.mostraFitxesUsuari();
                    
                        System.out.println("\n");
                        System.out.print("Escriu la paraula: ");
                        Paraula paraulaRespostaJ2 = Paraula.llegeix();
                    
                        if(paraulaRespostaJ2.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosCatala(paraulaRespostaJ2)){
                            System.out.println("Vàlida");
                            puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ2);
                            System.out.println("Punts guanyats: " + puntsGuanyats);
                            
                            puntuacioJ2 += puntsGuanyats;
                            System.out.println("Total: "+ puntuacioJ2 + " punts.");
                        } else{
                            System.out.println("No vàlida. -10 punts");
                            puntuacioJ2 -= 10;
                            System.out.println("Total: "+ puntuacioJ2 + " punts.");
                        
                        } 

                        //Si ha triat 3 jugadors o 4, el jugador 3 comença a jugar.
                        if(jugadors == 3 || jugadors == 4){
                            System.out.println("\n");
                            System.out.println("Torn de '" + nomJugador3 + "'." + "\n");
                        
                            PVP.creaNovesFitxes();
                            System.out.println("Crea una paraula amb les següents fitxes: ");

                            PVP.mostraFitxesUsuari();  
                            
                            System.out.println("\n");
                            System.out.print("Escriu la paraula: ");
                            Paraula paraulaRespostaJ3 = Paraula.llegeix();
                    
                            if(paraulaRespostaJ3.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosCatala(paraulaRespostaJ3)){
                                System.out.println("Vàlida");
                                puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ3);
                                System.out.println("Punts guanyats: " + puntsGuanyats);
                            
                                puntuacioJ3 += puntsGuanyats;
                                System.out.println("Total: "+ puntuacioJ3 + " punts.");
                                
                            } else{
                                System.out.println("No vàlida. -10 punts");
                                puntuacioJ3 -= 10;
                                System.out.println("Total: "+ puntuacioJ3 + " punts.");
                        
                            } 
                        }
                        
                        //Si s'han escogit 4 jugadors, el jugador 4 comença a jugar.
                        if(jugadors == 4){
                            
                            System.out.println("\n");
                            System.out.println("Torn de '" + nomJugador4 + "'." + "\n");
                            PVP.creaNovesFitxes();
                            System.out.println("Crea una paraula amb les següents fitxes: ");

                            PVP.mostraFitxesUsuari();
                            
                            System.out.println("\n");
                            System.out.print("Escriu la paraula: ");
                            Paraula paraulaRespostaJ4 = Paraula.llegeix();
                    
                            if(paraulaRespostaJ4.paraulaValida(PVP.retornaFitxesUsuari()) && estaInclosCatala(paraulaRespostaJ4)){
                                System.out.println("Vàlida");
                                puntsGuanyats =PVP.retornaPunts(paraulaRespostaJ4);
                                System.out.println("Punts guanyats: " + puntsGuanyats);
                            
                                puntuacioJ4 += puntsGuanyats;
                                System.out.println("Total: "+ puntuacioJ4 + " punts.");
                                
                            } else{
                                System.out.println("No vàlida. -10 punts");
                                puntuacioJ4 -= 10;
                                System.out.println("Total: "+ puntuacioJ4 + " punts.");
                        
                            }
                        }
                                              
                        rondaActualPVP++; // Quan s'han acabat els torn de tots els jugadors de la ronda, se li suma una unitat al marcador de rondes.
                        System.out.println("\n");
                    }                    
                    
                    System.out.println("La partida ha acabat!");
                    
                    if (jugadors == 2) {
                        
                        if (puntuacioJ1 > puntuacioJ2) {
                            System.out.println("El guanyador és '" + nomJugador1 + "' amb " + puntuacioJ1 + " punts.");
                            puntuacioGuanyadora = puntuacioJ1;
                            nomGuanyador.ompleParaula(nomJugador1);
                        } else if(puntuacioJ1 > puntuacioJ1) {
                            System.out.println("El guanyador és '" + nomJugador2 + "' amb " + puntuacioJ2 + " punts.");
                            puntuacioGuanyadora = puntuacioJ2;
                            nomGuanyador.ompleParaula(nomJugador2);

                        } else{
                            System.out.println("Empat!");
                            puntuacioGuanyadora = -300;
                        }
                        
                    } else if (jugadors == 3) {
                        
                        if (puntuacioJ3 > puntuacioJ1 && puntuacioJ3 > puntuacioJ2) {
                            System.out.println("El guanyador és '" + nomJugador3 + "' amb " + puntuacioJ3 + " punts.");
                            puntuacioGuanyadora = puntuacioJ3;
                            nomGuanyador.ompleParaula(nomJugador3);

                        } else if (puntuacioJ2 > puntuacioJ1 && puntuacioJ2 > puntuacioJ3) {
                            System.out.println("El guanyador és '" + nomJugador2 + "' amb " + puntuacioJ2 + " punts.");
                            puntuacioGuanyadora = puntuacioJ2;
                            nomGuanyador.ompleParaula(nomJugador2);                            
                        } else if(puntuacioJ1 > puntuacioJ2 && puntuacioJ1 > puntuacioJ3) {
                            System.out.println("El guanyador és '" + nomJugador1 + "' amv " + puntuacioJ1 + " punts.");
                            puntuacioGuanyadora = puntuacioJ1;
                            nomGuanyador.ompleParaula(nomJugador1);                            
                        } else{
                            
                            System.out.println("Empat!");
                            puntuacioGuanyadora = -300;
                            
                        }
                        
                    } else {
                        
                        if (puntuacioJ4 > puntuacioJ1 && puntuacioJ4 > puntuacioJ2 && puntuacioJ4 > puntuacioJ3) {
                            System.out.println("El guanyador és '" + nomJugador4 + "' amb " + puntuacioJ4 + " punts.");
                            puntuacioGuanyadora = puntuacioJ4;
                            nomGuanyador.ompleParaula(nomJugador4);                            
                        } else if (puntuacioJ3 > puntuacioJ1 && puntuacioJ3 > puntuacioJ2 && puntuacioJ3 > puntuacioJ4) {
                            System.out.println("El guanyador és '" + nomJugador3 + "' amb " + puntuacioJ3 + " punts.");
                            puntuacioGuanyadora = puntuacioJ3;
                            nomGuanyador.ompleParaula(nomJugador3);                            
                        } else if (puntuacioJ2 > puntuacioJ1 && puntuacioJ2 > puntuacioJ3 && puntuacioJ2 > puntuacioJ4) {
                            System.out.println("El guanyador és '" + nomJugador2 + "' amb " + puntuacioJ2 + " punts.");
                            puntuacioGuanyadora = puntuacioJ2;
                            nomGuanyador.ompleParaula(nomJugador2);                            
                        } else if (puntuacioJ1 > puntuacioJ2 && puntuacioJ1 > puntuacioJ3 && puntuacioJ1 > puntuacioJ4){
                            System.out.println("El guanyador és '" + nomJugador1 + "' amb " + puntuacioJ1 + " punts.");
                            puntuacioGuanyadora = puntuacioJ1;
                            nomGuanyador.ompleParaula(nomJugador1);                            
                        }
                        else{
                            System.out.println("Empat!");
                            puntuacioGuanyadora = -300;
                        }
                    }
                }
                
                historial.escriuHistorialPVP(nomJugador1, nomJugador2, nomJugador3, nomJugador4, puntuacioGuanyadora, nomGuanyador, jugadors, idiomaEspañol);
                
                break;
                
            default:
                break;
        }

    }
    
    // Mètode que et diu si la paraula introduïda està inclosa al diccionari en Espanyol
    private static boolean estaInclosEspañol(Paraula paraulaCercada)throws Exception{
        
        boolean estaInclos = false;
        FitxerParaulesEntrada diccionari = new FitxerParaulesEntrada("esp.dic");
        
        while(!estaInclos && diccionari.codi() != diccionari.CODI_FINAL()){
            diccionari.cercaParaula();
            Paraula paraulaDiccionari = diccionari.llegeixParaula();
            if (paraulaCercada.equals(paraulaDiccionari) ) {
                estaInclos = true;
            }

        }
        
        diccionari.tanca();
        return estaInclos;
    }

    // Mètode que et diu si la paraula introduïda està inclosa al diccionari en Català    
    private static boolean estaInclosCatala(Paraula paraulaCercada)throws Exception{
        
        boolean estaInclos = false;
        FitxerParaulesEntrada diccionari = new FitxerParaulesEntrada("cat.dic");
        
        while(!estaInclos && diccionari.codi() != diccionari.CODI_FINAL()){
            diccionari.cercaParaula();
            Paraula paraulaDiccionari = diccionari.llegeixParaula();
            if (paraulaCercada.equals(paraulaDiccionari) ) {
                estaInclos = true;
            }
            
        }
        
        diccionari.tanca();
        return estaInclos;
    }
    
}