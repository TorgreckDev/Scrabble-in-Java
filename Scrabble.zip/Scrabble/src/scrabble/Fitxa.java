/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scrabble;



/**
 *
 * @authors Sebastià Ballester & Xavier Carbonell
 */
public class Fitxa {
    
    /*
    * Atributs de la classe fitxa
    */
    
    private char[] fitxesUsuari;
    private static char[] lletres;
    private static int[] valorLletres;
    private static char[] alfabet;
    
    /*
    * Constructor (crea un sac i a partir d'aquest soretja un conjunt de 11 fitxes aleatòries d'aquest).
    */
    
    public Fitxa()throws Exception{
        
        creaSacs();
        
        fitxesUsuari = sorteigFitxes(); 
        
        
    }
    
    /*
    * Mètodes no statics de la classe fitxa
    */
    
    // Mètode que mostra les fitxes que li han tocat al jugador.
    public void mostraFitxesUsuari(){
        for (int i = 0; i < 11; i++) {
           System.out.print( " [" + fitxesUsuari[i] + "] ");
        }
    }
    
    
    // Mètode que retorna les fitxes del jugador.
    public char[] retornaFitxesUsuari(){
        return fitxesUsuari;
    }
    
    //Mètode que fa un sorteig de fitxes d'un sac ja creat i modificat.
    public void creaNovesFitxes(){
        fitxesUsuari = sorteigFitxes();
    }
    
    //
    public int retornaPunts(Paraula resposta){
        
        int punts = 0;
        
        
        for (int i = 0; i < resposta.longitud(); i++) {
            int j = 0;
            boolean lletraTrobada = false;
            
            while(!lletraTrobada && j < alfabet.length ){
                
                if(resposta.lletraA(i)==alfabet[j]){
                    punts += valorLletres[j];
                    lletraTrobada = true;
                }
                
                j++;
            }
            
            
        }
        
        
        return punts;
    }
    
    public void agafaFitxes(Fitxa fitxa){
        for (int i = 0; i < fitxesUsuari.length; i++) {
            fitxesUsuari[i] = fitxa.fitxesUsuari[i];
        }
    }
    
    /*
    * Mètodes statics de la classe fitxa.
    */
    
    // Mètode que crea el sac d'on s'agafaran les fitxes.
    public static void creaSacs()throws Exception {
        
        int totalFitxes, valorFitxa, repeticions, i, j, posicioValor;

        char lletra;
        
        
        FitxerTextEntrada fte = new FitxerTextEntrada("alfabet.alf");

        if (fte.quedenElements()) {

            totalFitxes = fte.llegeixEnter();
            lletres = new char[totalFitxes];
            valorLletres = new int[26];
            alfabet = new char[valorLletres.length];

            i = 0;
            j = 0;

            while(fte.quedenElements()) {

                lletra = fte.llegeixLletra();
                alfabet[j] = lletra;

                if(fte.quedenElements()) {

                    repeticions = fte.llegeixEnter();

                    if(fte.quedenElements()) {

                        valorFitxa = fte.llegeixEnter();

                        valorLletres[j] = valorFitxa;
                        j++;

                        for(int index = 0; index < repeticions; index++) {

                            lletres[i] = lletra;
                            i++;
                            
                        }
                        

                    }

                }
                

            }

        }
        fte.tanca();
                    
    }
    
    
    // Mètode que du a terme el sorteig de fitxes del jugador
    private static char[] sorteigFitxes(){
        char[] resultat = new char[11];
        int posicioAleatoria;
        posicioAleatoria = (int)(Math.random() * 104);

        for (int i = 0; i < 11; i++) {
            while(lletres[posicioAleatoria] == '0'){
            posicioAleatoria = (int)(Math.random() * 104);

            }
            resultat[i] = lletres[posicioAleatoria];
            lletres[posicioAleatoria] = '0';
        }
        
        return resultat;
    }   
    
    
    
}
