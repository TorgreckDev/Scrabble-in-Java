/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scrabble;

import java.io.BufferedReader;
import java.io.FileReader;


/**
 *
 * @authors Sebastià Ballester & Xavier Carbonell
 */
public class FitxerParaulesEntrada {
    
    // Atributs
    private FileReader fr;
    private BufferedReader br;
    private int codi = CODI_ESPAI;
    
    // Constants
    private static final int CODI_FINAL = -1;
    private static final int CODI_ESPAI = (int) ' ';
    private static final int CODI_LF = (int) '\n';
    
    // Constructor (crea un nou fitxer per llegir paraules a partir del nom del fitxer indicat).
    public FitxerParaulesEntrada(String nomFitxer) throws Exception {
        fr = new FileReader(nomFitxer);
        br = new BufferedReader(fr);
    }
    
    //Mètode que cerca la següent paraula, bota els separadors entre elles.
    public void cercaParaula() throws Exception {
        while (codi == CODI_ESPAI || codi == CODI_LF) {
            codi = br.read();
        }
    }    
    
    // Mètode que cerca la paraula i et diu si en queden.
    public boolean quedenParaules() throws Exception {
        cercaParaula();
        return codi != CODI_FINAL;
    }
        
    // Mètodes que retornen atributs concrets de la classe.
    public int codi(){
        return codi;
    }
    public int CODI_FINAL(){
        return CODI_FINAL;
    }
    
    // Mètode que llegeix una paraula del fitxer una vegada s'ha creat.
    public Paraula llegeixParaula() throws Exception {
        Paraula p = new Paraula();
        
        while (codi != CODI_ESPAI && codi != CODI_LF && codi != CODI_FINAL && p.teCapacitat()) {
            p.afegeixLletra((char) codi);
            codi = br.read();
        }
        
        botaParaula();
        
        return p;
    }
    
    // Mètode que bota la resta de la paraula del fitxer.
    private void botaParaula() throws Exception {
        while (codi != CODI_ESPAI && codi != CODI_LF && codi != CODI_FINAL) {
            codi = br.read();
        }
    }
    
    // Mètode que tanca el fitxer.
    public void tanca() throws Exception {
        br.close();
        fr.close();
    }
    
    public void mostraHistorial() throws Exception {
        
        System.out.println("\n");
        
        while(codi != CODI_FINAL){
            
            System.out.print((char) codi);
            
            codi = br.read();
        }
        
        tanca();
        
    }
    
    
}
